#!/bin/sh
dtf ../plant.ssm ../step.dat o.dat
dcsloop dcsloop.par
