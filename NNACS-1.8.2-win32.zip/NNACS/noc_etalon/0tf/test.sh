#!/bin/sh
dtf ../plant.tf ../step.dat o.dat
dcsloop dcsloop.par
